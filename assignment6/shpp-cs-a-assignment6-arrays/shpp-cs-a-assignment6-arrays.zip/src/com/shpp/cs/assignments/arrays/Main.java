package com.shpp.cs.assignments.arrays;

public class Main {

    public static void main(String[] args) {
	    // no no, don't do anything here plz
        // just look at subpackages!!
    }
}
