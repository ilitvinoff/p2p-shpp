package com.shpp.cs.assignments.arrays.hg.teest;

public class ResultTypeHolder {

    public enum ResultType {SUCCESS, FAILURE, EXCEPTION}

}

