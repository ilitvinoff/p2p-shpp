package com.shpp.cs.assignments.arrays.sg;

public interface SteganographyConstants {
    int CANVAS_WIDTH = 400;
    int CANVAS_HEIGHT = 300;
}
