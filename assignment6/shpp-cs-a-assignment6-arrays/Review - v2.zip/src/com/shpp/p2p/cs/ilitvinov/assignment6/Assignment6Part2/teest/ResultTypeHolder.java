package com.shpp.p2p.cs.ilitvinov.assignment6.Assignment6Part2.teest;

public class ResultTypeHolder {

    public enum ResultType {SUCCESS, FAILURE, EXCEPTION}

}

