package com.shpp.p2p.cs.ilitvinov.assignment6.Assignment6Part1;

public interface SteganographyConstants {
    int CANVAS_WIDTH = 400;
    int CANVAS_HEIGHT = 300;
}
